function existInList(object, listObjects){
    for(j=0; j<listObjects.length; j++){
        if(object === listObjects[j]){
            return true;
        }
    }
    return false;
}

function calculate(numberInText){
    let timer = new Date().getTime();
    let digits = [];
    let counter = 2;
    let numberInTextAux = numberInText;
    const timeOut = 25000;
    while(digits.length != 2 && (new Date().getTime() - timer)<=timeOut){
        for(i=0; i<numberInText.length; i++){
            if(existInList(numberInText[i], digits) === false){
                digits.push(numberInText[i]);
            }
            if(digits.length > 2){
                break;
            }
        }
    
        if(digits.length != 2){
            digits = [];
            numberInText = String(Number(numberInTextAux)*counter);
            counter++;
        }
    }
    timer = (new Date().getTime() - timer);
    if(timer <= timeOut){
        return {'value': String(numberInText), 'timer': String(timer) + ' ms'};
    }else{
        return {'value': 'Time-out', 'timer': 'Time-out (25 ms)'};
    }
}

const cors = require('cors');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
let PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    app.use(cors());
    next();
});

app.listen(PORT, () => console.log('[]'));

app.get('/', (req, res) => {
    res.send('its working');
});

app.post('/', (req, res) => {
    req.setTimeout(50000);
    const query = req.body['number'];
    const result = calculate(query);
    res.send(result);
});